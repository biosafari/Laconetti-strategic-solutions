---
name: Due Diligence / Risk Analysis Request
about: Request a report or pre-investment review from Laconetti
title: "[Due Diligence Request] "
labels: risk, analysis
assignees: ''

---

## Company or Client Name:
<!-- Name of party requesting risk analysis -->

## Type of Report Needed:
<!-- e.g., Host Community Risk Assessment, ESG Viability, Regulatory Mapping -->

## Location:
<!-- Target region or community -->

## Purpose:
<!-- Why do you need this report? Investment? Legal? Operational? -->

## Timeline:
<!-- When do you need the output delivered? -->

We will confirm scope, pricing, and turnaround time after reviewing your request.

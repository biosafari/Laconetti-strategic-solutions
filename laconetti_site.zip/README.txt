Laconetti landing page. Deploy root as static site. Images in /assets/.
